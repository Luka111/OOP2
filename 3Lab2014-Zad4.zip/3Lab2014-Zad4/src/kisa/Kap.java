package kisa;

public class Kap {
	
	int x,y;
	double tezina;
	
	public Kap(int xx, int yy, double t){ x=xx; y=yy; tezina=t;}

}
