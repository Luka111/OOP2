package kisa;
import java.awt.*;

public interface Prikaziv {
	
	void crtaj();
	
}
