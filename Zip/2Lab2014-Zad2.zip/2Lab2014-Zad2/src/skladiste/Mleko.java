package skladiste;

public class Mleko extends Artikal {
	
	public Mleko(String n) throws GNePostoji { super(n,new Jedinica("l")); }
	
}
