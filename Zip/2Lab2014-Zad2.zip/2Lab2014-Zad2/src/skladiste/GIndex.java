package skladiste;

public class GIndex extends Exception {
	
	public String toString() { return "Nedzovoljen index;"; }
	
}
