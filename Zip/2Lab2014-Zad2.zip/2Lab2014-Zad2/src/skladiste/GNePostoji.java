package skladiste;

public class GNePostoji extends Exception {
	public String toString() { return "Oznaka ne postoji!"; }
}
