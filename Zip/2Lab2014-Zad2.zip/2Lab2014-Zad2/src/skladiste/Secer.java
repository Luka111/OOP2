package skladiste;

public class Secer extends Artikal {

	public Secer(String n) throws GNePostoji { super(n,new Jedinica("kg")); }
	
}
