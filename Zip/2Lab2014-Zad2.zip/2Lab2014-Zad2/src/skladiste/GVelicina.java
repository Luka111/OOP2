package skladiste;

public class GVelicina extends Exception {
	
	public String toString() { return "Nedozvoljena velicina niza!"; }
	
}
