package skladiste;

public class GNema extends Exception {
	
	public String toString() { return "Nema zapisa sa zadatim nazivom artikla!"; }
	
}
