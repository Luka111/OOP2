package skladiste;

public interface Vrednosno {
	double vrednost();
}
