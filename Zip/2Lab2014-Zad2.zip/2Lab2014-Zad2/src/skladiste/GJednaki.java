package skladiste;

public class GJednaki extends Exception {

	public String toString() { return "Artikal vec postoji!"; }
	
}
