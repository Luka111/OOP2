package radionica;

public abstract class Mehanizam {
	
	public abstract void radnja() throws InterruptedException;
	
}
