package radionica;

public class Proizvod {
	
	private static int posId = 0;
	private int id = ++posId;
	
	public String toString() { return Integer.toString(id); }
	
}
