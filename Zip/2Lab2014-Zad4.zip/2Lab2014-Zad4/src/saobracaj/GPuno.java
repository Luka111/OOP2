package saobracaj;

public class GPuno extends Exception {

	public String toString() { return "***Prepunili ste rezervoar!***"; }
	
}
